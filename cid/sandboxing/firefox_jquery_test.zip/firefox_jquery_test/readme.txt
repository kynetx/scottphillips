This is a sample plugin that runs the jquery unit test.

There are two ways to run

1st - Normal browser no in page-mod
	- Just open test_no_page_mod.html in your firefox browser and test test will run.
	- For some reason a hand full of test do not pass but you will get an idea of what should pass.
	
	
2nd - Use this jet-pack extension
	- First you must copy the data directory to a webserver.
	- Second you must copy the test_in_pagemod.html to your webserver
	- Third run the jetpack cfx run
	- Fourth go the the test_in_pagemod.html and test test should start to 
		run.		
	- See that only a few start pass and infact they break almost right away and do not run all the test.
	
	
	