<?php header('HTTP/1.0 304 Not Modified'); exit; ?>
